angular.module('popup')
  .controller('MainController', ['$scope', function($scope) {

      $scope.welcomeMsg = "This is a option page";


  }])
;
